#!/bin/bash

#Usage:
#sudo bash run-huawei-full.sh [/path/to/system.img]

sudo ./run.sh 64 $1
sudo ./run-huawei.sh s.img

