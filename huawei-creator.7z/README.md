# Usage


Generate ARM64 A-only from ARM64 AB (target image name is s.img):

    sudo bash run.sh 64 systemAB.img

Generate ARM64 A-only (Huawei device) from ARM64 A-only:

    sudo bash run-huawei.sh system-AOnly.img

