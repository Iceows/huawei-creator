#!/sbin/sh


	# Set owner and permissions
	chmod 750 /system_root/system/bin/gnss_watchlssd_thirdparty
	chown gps:system /system_root/system/bin/gnss_watchlssd_thirdparty

	chcon -v u:object_r:hi110x_daemon_exec:s0 /system_root/system/bin/gnss_watchlssd_thirdparty
	chcon -v u:object_r:system_lib_file:s0 /system_root/system/lib/libgnss_lss_gw_thirdparty.so
	chcon -v u:object_r:system_lib_file:s0 /system_root/system/lib64/libgnss_lss_gw_thirdparty.so

	# ------------------------------------ #


	# For gnss_lss
	echo "/system/bin/gnss_watchlssd_thirdparty		u:object_r:hi110x_daemon_exec:s0" >> /system_root/system/etc/selinux/plat_file_contexts 
	echo "(allow hi110x_daemon self (fifo_file (ioctl read write create getattr setattr lock append unlink rename open)))" >> /system_root/system/etc/selinux/plat_sepolicy.cil
	echo "(allow hi110x_daemon system_data_root_file (dir (read write)))" >> /system_root/system/etc/selinux/plat_sepolicy.cil
	echo "(allow hi110x_daemon socket_device (dir (read write)))" >> /system_root/system/etc/selinux/plat_sepolicy.cil

	# For lss 
	sed -i '/(type alarm_device)/d' /system_root/system/etc/selinux/plat_sepolicy.cil
	sed -i '/(roletype object_r alarm_device)/d'  /system_root/system/etc/selinux/plat_sepolicy.cil
	sed -i '/(typeattributeset dev_type (device ashmem_device ashmem_libcutils_device audio_device binder_device uhid_device uio_device tun_device/d' /system_root/system/etc/selinux/plat_sepolicy.cil
	
	echo "(type alarm_device)" >> /system_root/system/etc/selinux/plat_sepolicy.cil
	echo "(roletype object_r alarm_device)" >> /system_root/system/etc/selinux/plat_sepolicy.cil
	echo "(typeattributeset dev_type (device ashmem_device ashmem_libcutils_device audio_device binder_device hwbinder_device vndbinder_device block_device camera_device dm_device keychord_device loop_control_device loop_device pmsg_device radio_device ram_device rtc_device vold_device console_device fscklogs gpu_device graphics_device hw_random_device input_device port_device lowpan_device mtp_device nfc_device ptmx_device kmsg_device kmsg_debug_device null_device random_device secure_element_device sensors_device serial_device socket_device alarm_device owntty_device tty_device video_device zero_device fuse_device iio_device ion_device qtaguid_device watchdog_device uhid_device uio_device tun_device usbaccessory_device usb_device usb_serial_device properties_device properties_serial property_info hci_attach_dev rpmsg_device root_block_device frp_block_device system_block_device recovery_block_device boot_block_device userdata_block_device cache_block_device swap_block_device metadata_block_device misc_block_device super_block_device sdcard_block_device ppp_device tee_device ))" >> /system_root/system/etc/selinux/plat_sepolicy.cil

	sed -i '/u:object_r:alarm_device:s0/d' /system_root/system/etc/selinux/plat_file_contexts 
	echo "/dev/alarm(/.*)?    u:object_r:alarm_device:s0" >> /system_root/system/etc/selinux/plat_file_contexts 

	# Hisupl (com.android.supl) - gnss_supl20service_hisi.apk (old version)
	echo "(allow system_app hi110x_daemon (unix_stream_socket (connectto create bind read write getattr setattr lock append listen accept getopt setopt shutdown)))" >> /system_root/system/etc/selinux/plat_sepolicy.cil
	echo "(allow system_app hal_hisupl_default (binder (call transfer)))" >> /system_root/system/etc/selinux/plat_sepolicy.cil 
	echo "(allow system_app hi110x_vendor_file (dir (search)))" >> /system_root/system/etc/selinux/plat_sepolicy.cil
	echo "(allow system_app hi110x_vendor_file (file (open read)))" >>  /system_root/system/etc/selinux/plat_sepolicy.cil 

	# ------------------------------------ #
	
	# From iceows supl20 apk (# Hisi)
	echo "is_hisi_connectivity_chip=1" >> /system_root/system/build.prop
	echo "ro.hardware.consumerir=hisi.hi6250" >> /system_root/system/build.prop		
	echo "ro.hardware.hisupl=hi1102"  >> /system_root/system/build.prop;
	
	# Fix system ntp_server (europe pool)
	set global ntp_server europe.pool.ntp.org

	# Allow agps an set config
	echo "persist.sys.pgps.config=1"  >> /system_root/system/build.prop;
	echo "assisted_gps_enabled=1"  >> /system_root/system/build.prop;

	# Uncomment to Debug GPS
	echo "log.tag.GnssConfiguration=DEBUG" >> /system_root/system/build.prop;
	echo "log.tag.GnssLocationProvider=DEBUG" >> /system_root/system/build.prop;
	echo "log.tag.GnssManagerService=DEBUG" >> /system_root/system/build.prop;
	echo "log.tag.NtpTimeHelper=DEBUG" >> /system_root/system/build.prop;
	
	# active le mode journalisation
	echo "ro.control_privapp_permissions=log" >> /system_root/system/build.prop;


	exit 0
